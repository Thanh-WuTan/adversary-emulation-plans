class Adversary:
    def __init__(self, adversary_id, abilities):
        self.adversary_id = adversary_id
        self.abilities = abilities