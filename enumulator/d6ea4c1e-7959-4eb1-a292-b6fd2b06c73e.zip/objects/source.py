class Source:
     def __init__(self, facts = set(), relationships = [], rules = ()):
          self.facts = facts
          self.relationships = relationships
          self.rules = rules